cd "$( dirname "${BASH_SOURCE[0]}" )"
curl -O http://vision.princeton.edu/marvin/models/vgg_imagenet/vgg16_imagenet_half.marvin
